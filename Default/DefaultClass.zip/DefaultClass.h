#pragma once
class $rootnamespace$
{
public:
	$rootnamespace$();
	~$rootnamespace$();

	$rootnamespace$(const $rootnamespace$& _Other) = delete;
	$rootnamespace$($rootnamespace$&& _Other) noexcept = delete;
	$rootnamespace$& operator=(const $rootnamespace$& _Other) = delete;
	$rootnamespace$& operator=($rootnamespace$&& _Other) noexcept = delete;

protected:


private:


};

