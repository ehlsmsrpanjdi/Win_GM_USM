#include "$rootnamespace$.h"

$rootnamespace$::$rootnamespace$()
{
}

$rootnamespace$::~$rootnamespace$()
{
}
